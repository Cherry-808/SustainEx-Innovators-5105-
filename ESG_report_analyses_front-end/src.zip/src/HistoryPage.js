import React from 'react';

function HistoryPage() {
  return (
    <div>
      <h2>Upload History</h2>
      <p>List of uploaded reports...</p>
    </div>
  );
}

export default HistoryPage;